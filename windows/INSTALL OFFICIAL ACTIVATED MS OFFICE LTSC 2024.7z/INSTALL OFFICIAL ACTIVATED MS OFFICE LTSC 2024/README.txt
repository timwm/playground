*** STEP 1. ***
Download the Office deployment tool from:
https://learn.microsoft.com/en-us/office/ltsc/2024/deploy#download-the-office-deployment-tool-from-the-microsoft-download-center

...And run the downloaded Office deployment tool executable as Administrator
  - When in the Office deployment tool dialog ("Select a folder to store the extracted files") you can create a folder or use an already existing folder

Note: We are only interested in the setup.exe file you may delete all other config
files (*.xml or all files except for setup.exe) since we already have/will generate a configuration.xml


*** STEP 2. ***
You can generate the configuration.xml file from:
https://config.office.com/deploymentsettings

...And save it as configuration.xml in the same folder as where the setup.exe file is (from STEP 1.)


*** STEP 3. ***
INSTALLING OFFICE
-----------------
Note: The commands we are using here can be got from the same link you use to download Office deployment tool in STEP 1

Open a command prompt in the folder where the setup.exe file is:
cd C:\\path\to\setup.exe\folder

...And run:
setup.exe /configure configuration.xml

Reference video: https://www.youtube.com/watch?v=Jh_w7dbnx0Q
When installation is done, you're all set, you can now use MS Office apps like MS Word.
That's it!




###################################################

ALTERNATIVELY

You can install with Microsoft 365. Download it from:
http://microsoft.com/en/microsoft-365/download-office

...And run the OfficeSetup.exe file